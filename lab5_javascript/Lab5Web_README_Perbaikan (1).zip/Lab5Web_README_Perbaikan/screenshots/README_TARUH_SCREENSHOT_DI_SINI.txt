Masukkan 8 screenshot asli ke folder ini. Nama file harus persis:
latihan1-output.png
latihan2-alert-prompt.png
latihan3-operasi-aritmetika.png
latihan4-if-else.png
latihan5-switch.png
latihan6-genap-ganjil.png
latihan7-ubah-warna.png
miniproject-kalkulator-nilai.png
